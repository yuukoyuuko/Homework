#include "namespace1.h"  

namespace MyNamespace {
    void function3();  
    void function4(); 
}
