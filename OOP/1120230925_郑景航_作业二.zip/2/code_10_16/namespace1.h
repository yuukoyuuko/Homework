namespace MyNamespace {
    void function1(); 
    void function2();  
}

