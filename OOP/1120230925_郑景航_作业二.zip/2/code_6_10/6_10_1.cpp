#include <iostream>
using namespace std;

class MyClass {
};

int main() {
    MyClass obj;
    cout << "对象创建成功" << endl;
    return 0;
}
