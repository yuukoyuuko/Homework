-- 修改基本表的结构
ALTER TABLE students
ADD student_age INTEGER;

ALTER TABLE students
DROP COLUMN student_age;